# Code_SCLL1_HSR
(Matlab code)

Hyperspectral Super-Resolution via Interpretable Block-Term Tensor Modeling

Meng Ding, Xiao Fu, Ting-Zhu Huang, Jun Wang, and Xi-Le Zhao

------------------------------------------------------------------------------------------------------------------------------------------------
Here, we propose a novel tensor-based hyperspectral super-resolution method via interpretable block-term tensor modeling.

------------------------------------------------------------------------------------------------------------------------------------------------
1). Get Started

Run Demo_super_resolution.

------------------------------------------------------------------------------------------------------------------------------------------------
2). Details

More detail can be found in [1]

[1] Meng Ding, Xiao Fu, Ting-Zhu Huang, Jun Wang, and Xi-Le Zhao. Hyperspectral Super-Resolution via Interpretable Block-Term Tensor Modeling.

------------------------------------------------------------------------------------------------------------------------------------------------
3). Please cite our paper if you use any part of our source code.
